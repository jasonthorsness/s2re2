CREATE FUNCTION s2re2_2024_08_18_match_inner(
    input LONGTEXT NOT NULL,
    pattern LONGTEXT NOT NULL)
    RETURNS TINYINT(1) NOT NULL
    AS WASM 
    FROM LOCAL INFILE 'match.wasm'
    USING EXPORT 'Match';

DELIMITER //
CREATE FUNCTION s2re2_2024_08_18_match(
    input LONGTEXT,
    pattern LONGTEXT)
RETURNS TINYINT(1) AS
DECLARE
    result RECORD(m TINYINT(1) NOT NULL, s LONGTEXT NOT NULL);
BEGIN
    IF ISNULL(input) OR ISNULL(pattern) THEN
        RETURN NULL;
    END IF;
    return s2re2_2024_08_18_match_inner(input, pattern);
END //

CREATE FUNCTION s2re2_2024_08_18_match_extract_inner(
    input LONGTEXT NOT NULL,
    pattern LONGTEXT NOT NULL)
    RETURNS RECORD(m TINYINT(1) NOT NULL, s LONGTEXT NOT NULL)
    AS WASM 
    FROM LOCAL INFILE 'match_extract.wasm'
    USING EXPORT 'MatchExtract';
   
DELIMITER //
CREATE FUNCTION s2re2_2024_08_18_match_extract(
    input LONGTEXT NULL,
    pattern LONGTEXT NULL)
RETURNS LONGTEXT AS
DECLARE
    result RECORD(m TINYINT(1) NOT NULL, s LONGTEXT NOT NULL);
BEGIN
    IF ISNULL(input) OR ISNULL(pattern) THEN
        RETURN NULL;
    END IF;
    result = s2re2_2024_08_18_match_extract_inner(input, pattern);
    IF result.m = 0 THEN
        RETURN NULL;
    ELSE
        RETURN result.s;
    END IF;
END //

